(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_src_daa91de1._.js",
  "static/chunks/node_modules__pnpm_f8621a74._.js"
],
    source: "dynamic"
});
