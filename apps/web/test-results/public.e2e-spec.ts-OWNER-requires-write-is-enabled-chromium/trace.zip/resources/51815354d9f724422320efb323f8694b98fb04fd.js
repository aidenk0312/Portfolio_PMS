(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/apps/web/src/components/ConfirmModal.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>ConfirmModal
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function ConfirmModal(param) {
    let { open, title = 'Are you sure?', description, confirmText = 'Confirm', cancelText = 'Cancel', onCancel, onConfirm, busy, children } = param;
    _s();
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConfirmModal.useEffect": ()=>setMounted(true)
    }["ConfirmModal.useEffect"], []);
    if (!mounted || !open) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-[1000] flex items-center justify-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-black/30",
                onClick: onCancel
            }, void 0, false, {
                fileName: "[project]/apps/web/src/components/ConfirmModal.tsx",
                lineNumber: 35,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative z-[1001] w-full max-w-sm rounded-xl bg-white p-4 shadow-lg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-base font-semibold mb-1",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/components/ConfirmModal.tsx",
                        lineNumber: 37,
                        columnNumber: 17
                    }, this),
                    description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-black/70 mb-3",
                        children: description
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/components/ConfirmModal.tsx",
                        lineNumber: 38,
                        columnNumber: 33
                    }, this),
                    children && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/components/ConfirmModal.tsx",
                        lineNumber: 39,
                        columnNumber: 30
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-end gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "rounded-md border px-3 py-1.5 text-sm",
                                onClick: onCancel,
                                disabled: busy,
                                children: cancelText
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/components/ConfirmModal.tsx",
                                lineNumber: 41,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "rounded-md border px-3 py-1.5 text-sm bg-black text-white hover:bg-black/90 disabled:opacity-60",
                                onClick: ()=>onConfirm(),
                                disabled: busy,
                                children: busy ? 'Working…' : confirmText
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/components/ConfirmModal.tsx",
                                lineNumber: 48,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/components/ConfirmModal.tsx",
                        lineNumber: 40,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/src/components/ConfirmModal.tsx",
                lineNumber: 36,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/src/components/ConfirmModal.tsx",
        lineNumber: 34,
        columnNumber: 9
    }, this), document.body);
}
_s(ConfirmModal, "LrrVfNW3d1raFE0BNzCTILYmIfo=");
_c = ConfirmModal;
var _c;
__turbopack_context__.k.register(_c, "ConfirmModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/hooks/useRBAC.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useRBAC": ()=>useRBAC
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function useRBAC() {
    _s();
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        role: 'NONE',
        canWrite: false,
        ready: false
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useRBAC.useEffect": ()=>{
            let alive = true;
            ({
                "useRBAC.useEffect": async ()=>{
                    try {
                        const sess = await fetch('/api/auth/session', {
                            cache: 'no-store'
                        }).then({
                            "useRBAC.useEffect": (r)=>r.ok ? r.json() : null
                        }["useRBAC.useEffect"]);
                        const token = sess === null || sess === void 0 ? void 0 : sess.apiToken;
                        const headers = token ? {
                            Authorization: "Bearer ".concat(token)
                        } : undefined;
                        const me = await fetch('/api/me', {
                            cache: 'no-store',
                            headers
                        }).then({
                            "useRBAC.useEffect": (r)=>r.ok ? r.json() : {
                                    role: 'NONE'
                                }
                        }["useRBAC.useEffect"]);
                        var _me_role;
                        const role = (_me_role = me === null || me === void 0 ? void 0 : me.role) !== null && _me_role !== void 0 ? _me_role : 'NONE';
                        const canWrite = role === 'OWNER' || role === 'ADMIN' || role === 'MEMBER';
                        if (!alive) return;
                        document.documentElement.dataset.ro = canWrite ? '0' : '1';
                        setState({
                            role,
                            canWrite,
                            ready: true
                        });
                    } catch (e) {
                        if (!alive) return;
                        document.documentElement.dataset.ro = '1';
                        setState({
                            role: 'NONE',
                            canWrite: false,
                            ready: true
                        });
                    }
                }
            })["useRBAC.useEffect"]();
            return ({
                "useRBAC.useEffect": ()=>{
                    alive = false;
                }
            })["useRBAC.useEffect"];
        }
    }["useRBAC.useEffect"], []);
    return state;
}
_s(useRBAC, "PuN0uKwAyorfkzCIKmnVAAKZv5E=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/components/role-badge.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>RoleBadge
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
function roleClasses(role) {
    switch(role){
        case 'OWNER':
            return 'border-violet-300 bg-violet-100 text-violet-700';
        case 'ADMIN':
            return 'border-rose-300 bg-rose-100 text-rose-700';
        case 'MEMBER':
            return 'border-emerald-300 bg-emerald-100 text-emerald-700';
        case 'VIEWER':
        default:
            return 'border-slate-300 bg-slate-100 text-slate-700';
    }
}
function RoleBadge() {
    _s();
    const [role, setRole] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [err, setErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RoleBadge.useEffect": ()=>{
            const ac = new AbortController();
            async function run() {
                try {
                    setLoading(true);
                    setErr(null);
                    let apiToken;
                    try {
                        const sess = await fetch('/api/auth/session', {
                            cache: 'no-store',
                            signal: ac.signal
                        });
                        if (sess.ok) {
                            const j = await sess.json();
                            apiToken = j === null || j === void 0 ? void 0 : j.apiToken;
                        }
                    } catch (e) {
                    /* no-op */ }
                    const res = await fetch('/api/me', {
                        cache: 'no-store',
                        signal: ac.signal,
                        headers: apiToken ? {
                            Authorization: "Bearer ".concat(apiToken)
                        } : undefined
                    });
                    if (!res.ok) {
                        throw new Error("HTTP ".concat(res.status));
                    }
                    const me = await res.json();
                    setRole(me.role);
                } catch (e) {
                    setErr((e === null || e === void 0 ? void 0 : e.message) || 'failed');
                } finally{
                    setLoading(false);
                }
            }
            run();
            return ({
                "RoleBadge.useEffect": ()=>ac.abort()
            })["RoleBadge.useEffect"];
        }
    }["RoleBadge.useEffect"], []);
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "inline-flex items-center rounded-full border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-500",
            "aria-busy": "true",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "mr-2 inline-block h-2 w-2 animate-pulse rounded-full bg-slate-400"
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/components/role-badge.tsx",
                    lineNumber: 80,
                    columnNumber: 9
                }, this),
                "Loading…"
            ]
        }, void 0, true, {
            fileName: "[project]/apps/web/src/components/role-badge.tsx",
            lineNumber: 76,
            columnNumber: 13
        }, this);
    }
    if (err || !role) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "inline-flex items-center rounded-full border border-slate-300 bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-700",
            children: "Role"
        }, void 0, false, {
            fileName: "[project]/apps/web/src/components/role-badge.tsx",
            lineNumber: 88,
            columnNumber: 13
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold ".concat(roleClasses(role)),
        title: "Current role: ".concat(role),
        children: role
    }, void 0, false, {
        fileName: "[project]/apps/web/src/components/role-badge.tsx",
        lineNumber: 95,
        columnNumber: 9
    }, this);
}
_s(RoleBadge, "HGdoh1gfQWRPpcdcmjsjRqe3W0Q=");
_c = RoleBadge;
var _c;
__turbopack_context__.k.register(_c, "RoleBadge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/lib/auth-events.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "emitAuthEvent": ()=>emitAuthEvent,
    "onAuthEvent": ()=>onAuthEvent
});
const subs = new Set();
function onAuthEvent(cb) {
    subs.add(cb);
    return ()=>{
        subs.delete(cb);
    };
}
function emitAuthEvent(type, payload) {
    subs.forEach((fn)=>fn(type, payload));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/components/auth-banners.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>AuthBanners
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/auth-events.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$4$2e$24$2e$11_next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19_jxk6cmjpwut5remrrtlx427luy$2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next-auth@4.24.11_next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19_jxk6cmjpwut5remrrtlx427luy/node_modules/next-auth/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function AuthBanners() {
    _s();
    const [show401, setShow401] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [show403, setShow403] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const t403 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthBanners.useEffect": ()=>{
            const off = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onAuthEvent"])({
                "AuthBanners.useEffect.off": (t)=>{
                    if (t === 'auth:401') setShow401(true);
                    if (t === 'auth:403') {
                        setShow403(true);
                        if (t403.current) clearTimeout(t403.current);
                        t403.current = window.setTimeout({
                            "AuthBanners.useEffect.off": ()=>setShow403(false)
                        }["AuthBanners.useEffect.off"], 3000);
                    }
                }
            }["AuthBanners.useEffect.off"]);
            return ({
                "AuthBanners.useEffect": ()=>{
                    if (t403.current) clearTimeout(t403.current);
                    off();
                }
            })["AuthBanners.useEffect"];
        }
    }["AuthBanners.useEffect"], []);
    if (!show401 && !show403) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-x-0 top-0 z-50 flex flex-col items-center gap-2 p-2",
        children: [
            show401 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full max-w-[1200px] rounded-xl border border-amber-200 bg-amber-50 px-4 py-2 text-amber-900 shadow",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-sm font-medium",
                            children: "Your session has expired."
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                            lineNumber: 34,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$2d$auth$40$4$2e$24$2e$11_next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19_jxk6cmjpwut5remrrtlx427luy$2f$node_modules$2f$next$2d$auth$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["signIn"])(),
                                    className: "inline-flex items-center rounded-lg border border-amber-300 bg-white px-3 py-1 text-sm font-medium hover:bg-amber-100",
                                    children: "Sign in again"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                                    lineNumber: 36,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setShow401(false),
                                    className: "inline-flex items-center rounded-lg px-2 py-1 text-sm",
                                    "aria-label": "Dismiss",
                                    children: "✕"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                                    lineNumber: 42,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                            lineNumber: 35,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                    lineNumber: 33,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                lineNumber: 32,
                columnNumber: 17
            }, this),
            show403 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full max-w-[1200px] rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 text-slate-800 shadow",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-sm",
                            children: "Insufficient permissions for this action."
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                            lineNumber: 56,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setShow403(false),
                            className: "inline-flex items-center rounded-lg px-2 py-1 text-sm",
                            "aria-label": "Dismiss",
                            children: "✕"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                            lineNumber: 57,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                    lineNumber: 55,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/web/src/components/auth-banners.tsx",
                lineNumber: 54,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/src/components/auth-banners.tsx",
        lineNumber: 30,
        columnNumber: 9
    }, this);
}
_s(AuthBanners, "B6kQW79I4FvGivB/m1VkmQWpdz0=");
_c = AuthBanners;
var _c;
__turbopack_context__.k.register(_c, "AuthBanners");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/lib/fetcher.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "apiFetch": ()=>apiFetch
});
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/auth-events.ts [app-client] (ecmascript)");
;
let cachedToken = null;
let lastFetch = 0;
async function getApiToken() {
    const now = Date.now();
    if (cachedToken && now - lastFetch < 10000) return cachedToken;
    try {
        const r = await fetch('/api/auth/session', {
            cache: 'no-store'
        });
        if (!r.ok) return null;
        const j = await r.json().catch(()=>({}));
        var _j_apiToken;
        cachedToken = (_j_apiToken = j === null || j === void 0 ? void 0 : j.apiToken) !== null && _j_apiToken !== void 0 ? _j_apiToken : null;
        lastFetch = now;
        return cachedToken;
    } catch (e) {
        return null;
    }
}
async function apiFetch(input) {
    let init = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    const method = String(init.method || 'GET').toUpperCase();
    const headers = new Headers(init.headers || {});
    if (method !== 'GET' && !headers.has('Authorization')) {
        const token = await getApiToken();
        if (token) headers.set('Authorization', "Bearer ".concat(token));
    }
    const res = await fetch(input, {
        ...init,
        headers
    });
    if (res.status === 401) (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:401');
    if (res.status === 403) (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
    return res;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/apps/web/src/app/kanban/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": ()=>KanbanPage
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@15.4.7_@playwright+test@1.56.0_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/components/Toast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ConfirmModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/components/ConfirmModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@dnd-kit+core@6.3.1_react-dom@19.1.0_react@19.1.0__react@19.1.0/node_modules/@dnd-kit/core/dist/core.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@dnd-kit+sortable@10.0.0_@dnd-kit+core@6.3.1_react-dom@19.1.0_react@19.1.0__react@19.1.0__react@19.1.0/node_modules/@dnd-kit/sortable/dist/sortable.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$utilities$40$3$2e$2$2e$2_react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@dnd-kit+utilities@3.2.2_react@19.1.0/node_modules/@dnd-kit/utilities/dist/utilities.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$hooks$2f$useRBAC$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/hooks/useRBAC.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$role$2d$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/components/role-badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$auth$2d$banners$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/components/auth-banners.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/auth-events.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/lib/fetcher.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
const WS = ("TURBOPACK compile-time value", "ws_local");
function cn() {
    for(var _len = arguments.length, a = new Array(_len), _key = 0; _key < _len; _key++){
        a[_key] = arguments[_key];
    }
    return a.filter(Boolean).join(' ');
}
const baseBtn = 'inline-flex items-center justify-center rounded-xl border px-3 py-2 text-sm font-medium transition focus-visible:outline-none focus-visible:ring-2 disabled:opacity-60 disabled:cursor-not-allowed';
const btn = "".concat(baseBtn, " border-slate-200 bg-white text-slate-900 hover:bg-slate-50 focus-visible:ring-indigo-500/60");
const btnPrimary = "".concat(baseBtn, " border-transparent bg-indigo-600 text-white hover:bg-indigo-500 focus-visible:ring-indigo-500/70");
const btnDanger = "".concat(baseBtn, " border-transparent bg-red-500 text-white hover:bg-red-600 focus-visible:ring-red-500/60");
const btnWarn = "".concat(baseBtn, " border-transparent bg-amber-400 text-black hover:bg-amber-300 focus-visible:ring-amber-400/60");
const input = 'w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 placeholder:text-slate-500/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500/60';
const card = 'rounded-2xl border border-slate-200 bg-white shadow-[0_1px_2px_0_rgb(0_0_0/0.05),0_6px_16px_-8px_rgb(0_0_0/0.15)]';
function SortableIssue(param) {
    let { issue, children, draggable } = param;
    _s();
    const { attributes, listeners, setNodeRef, transform, transition, isDragging, setActivatorNodeRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSortable"])({
        id: issue.id
    });
    const style = {
        transform: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$utilities$40$3$2e$2$2e$2_react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS"].Transform.toString(transform),
        transition
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
        ref: setNodeRef,
        style: style,
        className: cn(card, 'p-3', isDragging && 'opacity-70'),
        "data-id": issue.id,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: setActivatorNodeRef,
            ...draggable ? {
                ...attributes,
                ...listeners
            } : {},
            className: cn(!draggable && 'cursor-not-allowed opacity-60'),
            children: children
        }, void 0, false, {
            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
            lineNumber: 97,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
        lineNumber: 91,
        columnNumber: 9
    }, this);
}
_s(SortableIssue, "RwvjOGy29eSz8G7MgGusvN+Fusk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSortable"]
    ];
});
_c = SortableIssue;
function SortableColumn(props) {
    _s1();
    const { column, draggable, headerLeft, headerRight, children } = props;
    const { attributes, listeners, setNodeRef, transform, transition, isDragging, setActivatorNodeRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSortable"])({
        id: column.id
    });
    const style = {
        transform: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$utilities$40$3$2e$2$2e$2_react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$utilities$2f$dist$2f$utilities$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CSS"].Transform.toString(transform),
        transition
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        ref: setNodeRef,
        style: style,
        "data-col-id": column.id,
        className: cn(card, 'p-4', isDragging && 'opacity-70'),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: cn(draggable ? 'cursor-grab active:cursor-grabbing' : 'cursor-not-allowed opacity-60', 'mb-3 flex items-center justify-between'),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: setActivatorNodeRef,
                        ...draggable ? {
                            ...attributes,
                            ...listeners
                        } : {},
                        children: headerLeft
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                        lineNumber: 132,
                        columnNumber: 17
                    }, this),
                    headerRight
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                lineNumber: 126,
                columnNumber: 13
            }, this),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
        lineNumber: 120,
        columnNumber: 9
    }, this);
}
_s1(SortableColumn, "RwvjOGy29eSz8G7MgGusvN+Fusk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSortable"]
    ];
});
_c1 = SortableColumn;
function KanbanPage() {
    _s2();
    const [allBoards, setAllBoards] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedBoardIds, setSelectedBoardIds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [columns, setColumns] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [err, setErr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [newColumn, setNewColumn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [newIssueTitleByCol, setNewIssueTitleByCol] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [editingColumn, setEditingColumn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editingIssue, setEditingIssue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [confirm, setConfirm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        open: false,
        title: ''
    });
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [cascade, setCascade] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [pickerOpen, setPickerOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeDrag, setActiveDrag] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [overlay, setOverlay] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const { push } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const workspaceId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "KanbanPage.useMemo[workspaceId]": ()=>WS !== null && WS !== void 0 ? WS : ''
    }["KanbanPage.useMemo[workspaceId]"], []);
    const { role, canWrite, ready } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$hooks$2f$useRBAC$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRBAC"])();
    const readOnly = ready ? !canWrite : false;
    const singleBoardMode = selectedBoardIds.length === 1;
    var _allBoards_find;
    const activeBoard = singleBoardMode ? (_allBoards_find = allBoards.find((b)=>b.id === selectedBoardIds[0])) !== null && _allBoards_find !== void 0 ? _allBoards_find : null : null;
    const pointerSensor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensor"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PointerSensor"], {
        activationConstraint: {
            distance: 6
        }
    });
    const sensors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensors"])(pointerSensor);
    const columnsByActive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "KanbanPage.useMemo[columnsByActive]": ()=>singleBoardMode && activeBoard ? columns.filter({
                "KanbanPage.useMemo[columnsByActive]": (c)=>c._board.id === activeBoard.id
            }["KanbanPage.useMemo[columnsByActive]"]) : columns
    }["KanbanPage.useMemo[columnsByActive]"], [
        singleBoardMode,
        activeBoard === null || activeBoard === void 0 ? void 0 : activeBoard.id,
        columns
    ]);
    const getColumnIds = ()=>columnsByActive.map((c)=>c.id);
    const getIssueIdsByColumn = (colId)=>{
        var _columnsByActive_find;
        var _columnsByActive_find_issues;
        return ((_columnsByActive_find_issues = (_columnsByActive_find = columnsByActive.find((c)=>c.id === colId)) === null || _columnsByActive_find === void 0 ? void 0 : _columnsByActive_find.issues) !== null && _columnsByActive_find_issues !== void 0 ? _columnsByActive_find_issues : []).map((i)=>i.id);
    };
    const withBusy = async (key, f)=>{
        setBusy(key);
        try {
            return await f();
        } finally{
            setBusy((k)=>k === key ? null : k);
        }
    };
    const jsonOrThrow = async (r, fallbackMsg)=>{
        if (r.ok) return r.json().catch(()=>({}));
        if (r.status === 403) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
            throw new Error('FORBIDDEN');
        }
        if (r.status === 401) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:401');
            throw new Error('UNAUTHORIZED');
        }
        throw new Error("".concat(fallbackMsg, ": ").concat(r.status));
    };
    const fetchFullBoard = async (id)=>{
        const r = await fetch("/api/boards/".concat(id, "/full"), {
            cache: 'no-store'
        });
        if (!r.ok) throw new Error("GET /boards/:id/full ".concat(r.status));
        return r.json();
    };
    const load = async ()=>{
        if (!workspaceId) {
            setErr('NEXT_PUBLIC_WORKSPACE_ID is empty.');
            setLoading(false);
            return;
        }
        setLoading(true);
        setErr(null);
        try {
            const rBoards = await fetch("/api/boards?workspaceId=".concat(workspaceId), {
                cache: 'no-store'
            });
            if (!rBoards.ok) throw new Error("GET /boards ".concat(rBoards.status));
            const boards = await rBoards.json();
            const sorted = boards.slice().sort((a, b)=>{
                var _a_order, _b_order;
                return ((_a_order = a.order) !== null && _a_order !== void 0 ? _a_order : 0) - ((_b_order = b.order) !== null && _b_order !== void 0 ? _b_order : 0);
            });
            setAllBoards(sorted);
            const selected = selectedBoardIds.length ? selectedBoardIds : sorted[0] ? [
                sorted[0].id
            ] : [];
            if (selected.join('|') !== selectedBoardIds.join('|')) setSelectedBoardIds(selected);
            if (selected.length === 0) {
                setColumns([]);
                setLoading(false);
                return;
            }
            const fulls = await Promise.all(selected.map((id)=>fetchFullBoard(id)));
            const merged = [];
            for (const fb of fulls){
                var _fb_columns;
                const cols = ((_fb_columns = fb.columns) !== null && _fb_columns !== void 0 ? _fb_columns : []).slice().sort((a, b)=>{
                    var _a_order, _b_order;
                    return ((_a_order = a.order) !== null && _a_order !== void 0 ? _a_order : 0) - ((_b_order = b.order) !== null && _b_order !== void 0 ? _b_order : 0);
                });
                cols.forEach((c)=>{
                    c.issues.sort((x, y)=>{
                        var _x_order, _y_order;
                        return ((_x_order = x.order) !== null && _x_order !== void 0 ? _x_order : 0) - ((_y_order = y.order) !== null && _y_order !== void 0 ? _y_order : 0) || new Date(x.createdAt).getTime() - new Date(y.createdAt).getTime();
                    });
                    merged.push({
                        ...c,
                        _board: {
                            id: fb.id,
                            name: fb.name
                        }
                    });
                });
            }
            setColumns(merged);
        } catch (e) {
            var _e_message;
            setErr((_e_message = e === null || e === void 0 ? void 0 : e.message) !== null && _e_message !== void 0 ? _e_message : 'load failed');
        } finally{
            setLoading(false);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "KanbanPage.useEffect": ()=>{
            load();
        }
    }["KanbanPage.useEffect"], [
        selectedBoardIds.join('|')
    ]);
    const createBoardQuick = async ()=>{
        if (!workspaceId || readOnly) return;
        const name = window.prompt('New board name');
        if (!(name === null || name === void 0 ? void 0 : name.trim())) return;
        await withBusy('create-board', async ()=>{
            const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])('/api/boards', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: name.trim(),
                    workspaceId
                })
            });
            await jsonOrThrow(r, 'Create board failed');
            push('Board created');
            await load();
        }).catch((e)=>{
            if ((e === null || e === void 0 ? void 0 : e.message) !== 'FORBIDDEN') push(e instanceof Error ? e.message : 'Create board failed');
        });
    };
    const createColumn = async ()=>{
        if (!activeBoard || readOnly) return;
        if (!newColumn.trim()) return;
        await withBusy('create-col', async ()=>{
            const body = {
                name: newColumn.trim(),
                boardId: activeBoard.id,
                order: columns.filter((c)=>c._board.id === activeBoard.id).length
            };
            const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])('/api/columns', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });
            await jsonOrThrow(r, 'Create column failed');
            setNewColumn('');
            push('Column created');
            await load();
        }).catch((e)=>{
            if ((e === null || e === void 0 ? void 0 : e.message) !== 'FORBIDDEN') push(e instanceof Error ? e.message : 'Create column failed');
        });
    };
    const createIssue = async (columnId)=>{
        if (readOnly) return;
        var _newIssueTitleByCol_columnId;
        const title = ((_newIssueTitleByCol_columnId = newIssueTitleByCol[columnId]) !== null && _newIssueTitleByCol_columnId !== void 0 ? _newIssueTitleByCol_columnId : '').trim();
        if (!title || !workspaceId) return;
        await withBusy("create-issue:".concat(columnId), async ()=>{
            const body = {
                title,
                workspaceId,
                columnId
            };
            const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])('/api/issues', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });
            await jsonOrThrow(r, 'Create issue failed');
            setNewIssueTitleByCol((m)=>({
                    ...m,
                    [columnId]: ''
                }));
            push('Issue created');
            await load();
        }).catch((e)=>{
            if ((e === null || e === void 0 ? void 0 : e.message) !== 'FORBIDDEN') push(e instanceof Error ? e.message : 'Create issue failed');
        });
    };
    const patchColumn = async (id, name)=>{
        if (readOnly) return;
        if (!name.trim()) return;
        await withBusy("rename-col:".concat(id), async ()=>{
            const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/columns/".concat(id), {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: name.trim()
                })
            });
            await jsonOrThrow(r, 'Update column failed');
            setEditingColumn(null);
            push('Column renamed');
            await load();
        }).catch((e)=>{
            if ((e === null || e === void 0 ? void 0 : e.message) !== 'FORBIDDEN') push(e instanceof Error ? e.message : 'Update column failed');
        });
    };
    const patchIssue = async (id, title)=>{
        if (readOnly) return;
        if (!title.trim()) return;
        await withBusy("rename-issue:".concat(id), async ()=>{
            const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/issues/".concat(id), {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    title: title.trim()
                })
            });
            await jsonOrThrow(r, 'Update issue failed');
            setEditingIssue(null);
            push('Issue renamed');
            await load();
        }).catch((e)=>{
            if ((e === null || e === void 0 ? void 0 : e.message) !== 'FORBIDDEN') push(e instanceof Error ? e.message : 'Update issue failed');
        });
    };
    const askDeleteColumn = (id)=>{
        if (readOnly) return;
        setConfirm({
            open: true,
            title: 'Delete this column?',
            desc: 'All issues in the column will be deleted.',
            onYes: async ()=>{
                setConfirm((c)=>({
                        ...c,
                        open: true
                    }));
                try {
                    const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/columns/".concat(id), {
                        method: 'DELETE'
                    });
                    if (r.status === 403) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
                        return;
                    }
                    if (!r.ok) throw new Error("Delete column failed: ".concat(r.status));
                    push('Column deleted');
                    await load();
                } finally{
                    setConfirm({
                        open: false,
                        title: ''
                    });
                }
            },
            kind: 'column'
        });
    };
    const askClearColumns = ()=>{
        if (!activeBoard || readOnly) return;
        setConfirm({
            open: true,
            title: 'Delete ALL columns on this board?',
            desc: 'This will delete every column and its issues. This cannot be undone.',
            onYes: async ()=>{
                setConfirm((c)=>({
                        ...c,
                        open: true
                    }));
                try {
                    const r = await fetch("/api/columns?boardId=".concat(activeBoard.id), {
                        cache: 'no-store'
                    });
                    if (r.status === 403) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
                        return;
                    }
                    if (!r.ok) throw new Error("GET /columns ".concat(r.status));
                    const cols = await r.json();
                    for (const c of cols){
                        const del = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/columns/".concat(c.id), {
                            method: 'DELETE'
                        });
                        if (del.status === 403) {
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
                            return;
                        }
                    }
                    push('All columns deleted');
                    await load();
                } finally{
                    setConfirm({
                        open: false,
                        title: ''
                    });
                }
            },
            kind: 'column'
        });
    };
    const askDeleteIssue = (id)=>{
        if (readOnly) return;
        setConfirm({
            open: true,
            title: 'Delete this issue?',
            onYes: async ()=>{
                setConfirm((c)=>({
                        ...c,
                        open: true
                    }));
                try {
                    const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/issues/".concat(id), {
                        method: 'DELETE'
                    });
                    if (r.status === 403) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
                        return;
                    }
                    if (!r.ok) throw new Error("Delete issue failed: ".concat(r.status));
                    push('Issue deleted');
                    await load();
                } finally{
                    setConfirm({
                        open: false,
                        title: ''
                    });
                }
            },
            kind: 'issue'
        });
    };
    const askDeleteBoard = ()=>{
        if (!activeBoard || readOnly) return;
        setCascade(false);
        setConfirm({
            open: true,
            title: 'Delete this board?',
            desc: 'You can optionally delete all columns & issues together.',
            onYes: async ()=>{
                setConfirm((c)=>({
                        ...c,
                        open: true
                    }));
                try {
                    const qs = cascade ? '?cascade=true' : '';
                    const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/boards/".concat(activeBoard.id).concat(qs), {
                        method: 'DELETE'
                    });
                    if (r.status === 409 && !cascade) {
                        const ok = window.confirm('This board has columns/issues. Delete EVERYTHING (cascade)?');
                        if (ok) {
                            const r2 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/boards/".concat(activeBoard.id, "?cascade=true"), {
                                method: 'DELETE'
                            });
                            if (!r2.ok) throw new Error("Delete board failed: ".concat(r2.status));
                        } else {
                            push('Cancelled');
                            return;
                        }
                    } else if (r.status === 403) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
                        return;
                    } else if (!r.ok) {
                        throw new Error("Delete board failed: ".concat(r.status));
                    }
                    push(cascade ? 'Board deleted with all columns & issues' : 'Board deleted');
                    const nextSelected = selectedBoardIds.filter((x)=>x !== activeBoard.id);
                    setSelectedBoardIds(nextSelected.length ? nextSelected : []);
                    await load();
                } finally{
                    setConfirm({
                        open: false,
                        title: ''
                    });
                }
            },
            kind: 'board'
        });
    };
    const onDragStart = (e)=>{
        if (readOnly) return;
        const id = String(e.active.id);
        const col = columnsByActive.find((c)=>c.id === id);
        if (col) {
            setActiveDrag({
                kind: 'column',
                id
            });
            setOverlay(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: cn(card, 'px-3 py-2'),
                children: col.name
            }, void 0, false, {
                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                lineNumber: 481,
                columnNumber: 24
            }, this));
            return;
        }
        for (const c of columnsByActive){
            const iss = c.issues.find((i)=>i.id === id);
            if (iss) {
                setActiveDrag({
                    kind: 'issue',
                    id,
                    fromColumnId: c.id
                });
                setOverlay(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: cn(card, 'px-3 py-2 text-sm'),
                    children: iss.title
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                    lineNumber: 488,
                    columnNumber: 28
                }, this));
                return;
            }
        }
        setActiveDrag(null);
        setOverlay(null);
    };
    const onDragOver = (e)=>{
        var _e_over;
        if (readOnly) return;
        if (!activeDrag) return;
        const overId = ((_e_over = e.over) === null || _e_over === void 0 ? void 0 : _e_over.id) ? String(e.over.id) : null;
        if (!overId) return;
        if (activeDrag.kind === 'issue') {
            const fromColId = activeDrag.fromColumnId;
            let toColId = fromColId;
            const overCol = columnsByActive.find((c)=>c.id === overId);
            if (overCol) toColId = overCol.id;
            else {
                const host = columnsByActive.find((c)=>c.issues.some((i)=>i.id === overId));
                if (host) toColId = host.id;
            }
            if (!toColId || toColId === fromColId) return;
            setColumns((prev)=>{
                const clone = prev.map((c)=>({
                        ...c,
                        issues: [
                            ...c.issues
                        ]
                    }));
                const scoped = singleBoardMode && activeBoard ? clone.filter((c)=>c._board.id === activeBoard.id) : clone;
                const fromCol = scoped.find((c)=>c.id === fromColId);
                const toCol = scoped.find((c)=>c.id === toColId);
                if (!fromCol || !toCol) return prev;
                const fromIdx = fromCol.issues.findIndex((i)=>i.id === activeDrag.id);
                if (fromIdx < 0) return prev;
                const [moved] = fromCol.issues.splice(fromIdx, 1);
                moved.columnId = toCol.id;
                toCol.issues.push(moved);
                return clone;
            });
            setActiveDrag({
                kind: 'issue',
                id: activeDrag.id,
                fromColumnId: toColId
            });
        }
    };
    const onDragEnd = async (e)=>{
        var _e_over;
        if (readOnly) return;
        const activeId = String(e.active.id);
        const overId = ((_e_over = e.over) === null || _e_over === void 0 ? void 0 : _e_over.id) ? String(e.over.id) : null;
        try {
            if ((activeDrag === null || activeDrag === void 0 ? void 0 : activeDrag.kind) === 'column' && singleBoardMode && activeBoard) {
                if (!overId || activeId === overId) return;
                const ids = getColumnIds();
                const oldIndex = ids.indexOf(activeId);
                const newIndex = ids.indexOf(overId);
                if (oldIndex < 0 || newIndex < 0) return;
                const nextScoped = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrayMove"])(columnsByActive, oldIndex, newIndex);
                const others = columns.filter((c)=>c._board.id !== activeBoard.id);
                setColumns([
                    ...others,
                    ...nextScoped
                ]);
                const columnIds = nextScoped.map((c)=>c.id);
                const r = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])('/api/columns/reorder', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        boardId: activeBoard.id,
                        columnIds
                    })
                });
                if (r.status === 403) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
                    return;
                }
                push('Columns reordered');
                await load();
                return;
            }
            if ((activeDrag === null || activeDrag === void 0 ? void 0 : activeDrag.kind) === 'issue') {
                var _updatedScoped_find, _updatedScoped_find1;
                const fromColId = activeDrag.fromColumnId;
                let toColId = fromColId;
                if (overId) {
                    const overCol = columnsByActive.find((c)=>c.id === overId);
                    if (overCol) toColId = overCol.id;
                    else {
                        const host = columnsByActive.find((c)=>c.issues.some((i)=>i.id === overId));
                        if (host) toColId = host.id;
                    }
                }
                let updated = [];
                setColumns((prev)=>{
                    const clone = prev.map((c)=>({
                            ...c,
                            issues: [
                                ...c.issues
                            ]
                        }));
                    const scoped = singleBoardMode && activeBoard ? clone.filter((c)=>c._board.id === activeBoard.id) : clone;
                    const fromCol = scoped.find((c)=>c.id === fromColId);
                    const toCol = scoped.find((c)=>c.id === toColId);
                    if (!fromCol || !toCol) {
                        updated = prev;
                        return prev;
                    }
                    const fromIdx = fromCol.issues.findIndex((i)=>i.id === activeId);
                    if (fromIdx < 0) {
                        updated = prev;
                        return prev;
                    }
                    if (toColId === fromColId) {
                        const overIndex = overId ? toCol.issues.findIndex((i)=>i.id === overId) : toCol.issues.length - 1;
                        if (overIndex < 0) {
                            updated = prev;
                            return prev;
                        }
                        toCol.issues = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["arrayMove"])(toCol.issues, fromIdx, overIndex);
                    } else {
                        const overIndex = overId ? toCol.issues.findIndex((i)=>i.id === overId) : toCol.issues.length;
                        const [moved] = fromCol.issues.splice(fromIdx, 1);
                        moved.columnId = toCol.id;
                        const insertAt = overIndex < 0 ? toCol.issues.length : overIndex;
                        toCol.issues.splice(insertAt, 0, moved);
                    }
                    updated = clone;
                    return clone;
                });
                if (!updated) return;
                const base = updated !== null && updated !== void 0 ? updated : [];
                const updatedScoped = singleBoardMode && activeBoard ? base.filter((c)=>c._board.id === activeBoard.id) : base;
                var _updatedScoped_find_issues;
                const toIds = ((_updatedScoped_find_issues = (_updatedScoped_find = updatedScoped.find((c)=>c.id === toColId)) === null || _updatedScoped_find === void 0 ? void 0 : _updatedScoped_find.issues) !== null && _updatedScoped_find_issues !== void 0 ? _updatedScoped_find_issues : []).map((i)=>i.id);
                var _updatedScoped_find_issues1;
                const fromIds = ((_updatedScoped_find_issues1 = (_updatedScoped_find1 = updatedScoped.find((c)=>c.id === fromColId)) === null || _updatedScoped_find1 === void 0 ? void 0 : _updatedScoped_find1.issues) !== null && _updatedScoped_find_issues1 !== void 0 ? _updatedScoped_find_issues1 : []).map((i)=>i.id);
                if (fromColId === toColId) {
                    const r1 = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/columns/".concat(toColId, "/reorder"), {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            issueIds: toIds
                        })
                    });
                    if (r1.status === 403) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
                        return;
                    }
                } else {
                    const [r1, r2] = await Promise.all([
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/columns/".concat(toColId, "/reorder"), {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                issueIds: toIds
                            })
                        }),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$fetcher$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["apiFetch"])("/api/columns/".concat(fromColId, "/reorder"), {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                issueIds: fromIds
                            })
                        })
                    ]);
                    if (r1.status === 403 || r2.status === 403) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$lib$2f$auth$2d$events$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emitAuthEvent"])('auth:403');
                        return;
                    }
                }
                push('Reordered');
                await load();
            }
        } finally{
            setActiveDrag(null);
            setOverlay(null);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-slate-50 text-slate-900",
        "data-ui-scope": "kanban",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$auth$2d$banners$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                lineNumber: 659,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$ConfirmModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                open: confirm.open,
                title: confirm.title,
                description: confirm.desc,
                onCancel: ()=>setConfirm({
                        open: false,
                        title: ''
                    }),
                onConfirm: async ()=>confirm.onYes && await confirm.onYes(),
                children: confirm.kind === 'board' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "flex items-center gap-2 text-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "checkbox",
                            className: "size-4",
                            checked: cascade,
                            onChange: (e)=>setCascade(e.target.checked)
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                            lineNumber: 670,
                            columnNumber: 25
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            children: "Also delete all columns & issues (cascade)"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                            lineNumber: 676,
                            columnNumber: 25
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                    lineNumber: 669,
                    columnNumber: 21
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                lineNumber: 661,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto max-w-[1200px] space-y-6 px-6 py-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-3xl font-bold tracking-tight",
                                        children: "Project Management System"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                        lineNumber: 684,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-slate-600",
                                        children: [
                                            "Workspace: ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                                children: workspaceId || '(unset)'
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                lineNumber: 686,
                                                columnNumber: 40
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                        lineNumber: 685,
                                        columnNumber: 25
                                    }, this),
                                    singleBoardMode && activeBoard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-slate-600",
                                        children: [
                                            "Board: ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: activeBoard.name
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                lineNumber: 690,
                                                columnNumber: 40
                                            }, this),
                                            " (",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                                children: activeBoard.id
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                lineNumber: 690,
                                                columnNumber: 77
                                            }, this),
                                            ")"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                        lineNumber: 689,
                                        columnNumber: 29
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                lineNumber: 683,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setPickerOpen(true),
                                        className: btn,
                                        children: [
                                            "Boards: ",
                                            selectedBoardIds.length || 0,
                                            " selected"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                        lineNumber: 696,
                                        columnNumber: 25
                                    }, this),
                                    singleBoardMode && activeBoard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: askClearColumns,
                                        className: cn(btnWarn, 'requires-write'),
                                        title: "Delete all columns on this board",
                                        disabled: readOnly,
                                        children: "Clear Columns…"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                        lineNumber: 701,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: createBoardQuick,
                                        className: cn(btnPrimary, 'requires-write'),
                                        disabled: readOnly,
                                        children: "Add Board"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                        lineNumber: 711,
                                        columnNumber: 25
                                    }, this),
                                    singleBoardMode && activeBoard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: askDeleteBoard,
                                        className: cn(btnDanger, 'requires-write'),
                                        disabled: readOnly,
                                        children: "Delete Board…"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                        lineNumber: 716,
                                        columnNumber: 29
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: load,
                                        className: btn,
                                        children: "Refresh"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                        lineNumber: 721,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$role$2d$badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                        lineNumber: 725,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                lineNumber: 695,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                        lineNumber: 682,
                        columnNumber: 17
                    }, this),
                    err && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm text-red-600",
                        children: err
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                        lineNumber: 729,
                        columnNumber: 25
                    }, this),
                    loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-sm",
                        children: "Loading…"
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                        lineNumber: 730,
                        columnNumber: 29
                    }, this),
                    singleBoardMode && activeBoard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: cn(card, 'p-5'),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    value: newColumn,
                                    onChange: (e)=>setNewColumn(e.target.value),
                                    placeholder: "New column",
                                    className: cn(input, 'requires-write'),
                                    disabled: readOnly
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                    lineNumber: 735,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: createColumn,
                                    className: cn(btn, 'requires-write'),
                                    disabled: readOnly || busy === 'create-col',
                                    children: busy === 'create-col' ? 'Adding…' : 'Add Column'
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                    lineNumber: 742,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                            lineNumber: 734,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                        lineNumber: 733,
                        columnNumber: 21
                    }, this),
                    !!columnsByActive.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DndContext"], {
                        sensors: sensors,
                        collisionDetection: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["closestCenter"],
                        onDragStart: onDragStart,
                        onDragOver: onDragOver,
                        onDragEnd: onDragEnd,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid gap-4 md:grid-cols-3",
                                "data-columns-wrap": true,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SortableContext"], {
                                    items: getColumnIds(),
                                    strategy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rectSortingStrategy"],
                                    children: columnsByActive.map((col)=>{
                                        var _newIssueTitleByCol_col_id;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortableColumn, {
                                            column: col,
                                            draggable: singleBoardMode && !readOnly,
                                            headerLeft: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                children: [
                                                    !singleBoardMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "mr-2 inline-flex items-center rounded-full border border-slate-200 bg-slate-100 px-2.5 py-0.5 text-xs text-slate-600",
                                                        children: col._board.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                        lineNumber: 771,
                                                        columnNumber: 53
                                                    }, void 0),
                                                    (editingColumn === null || editingColumn === void 0 ? void 0 : editingColumn.id) === col.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                value: editingColumn.name,
                                                                onChange: (e)=>setEditingColumn({
                                                                        id: col.id,
                                                                        name: e.target.value
                                                                    }),
                                                                className: cn(input, 'h-8 w-44', 'requires-write'),
                                                                disabled: readOnly
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                lineNumber: 777,
                                                                columnNumber: 57
                                                            }, void 0),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: cn(btn, 'px-2 py-1 text-xs', 'requires-write'),
                                                                onClick: ()=>patchColumn(col.id, editingColumn.name.trim()),
                                                                disabled: readOnly || busy === "rename-col:".concat(col.id),
                                                                children: busy === "rename-col:".concat(col.id) ? 'Saving…' : 'Save'
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                lineNumber: 783,
                                                                columnNumber: 57
                                                            }, void 0),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: cn(btn, 'px-2 py-1 text-xs', 'requires-write'),
                                                                onClick: ()=>setEditingColumn(null),
                                                                disabled: readOnly,
                                                                children: "Cancel"
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                lineNumber: 790,
                                                                columnNumber: 57
                                                            }, void 0)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                        lineNumber: 776,
                                                        columnNumber: 53
                                                    }, void 0) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        className: "font-semibold",
                                                        children: col.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                        lineNumber: 799,
                                                        columnNumber: 53
                                                    }, void 0)
                                                ]
                                            }, void 0, true),
                                            headerRight: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-2",
                                                children: [
                                                    (editingColumn === null || editingColumn === void 0 ? void 0 : editingColumn.id) !== col.id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: cn(btn, 'px-2 py-1 text-xs', 'requires-write'),
                                                                onClick: ()=>setEditingColumn({
                                                                        id: col.id,
                                                                        name: col.name
                                                                    }),
                                                                disabled: readOnly,
                                                                children: "Rename"
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                lineNumber: 807,
                                                                columnNumber: 57
                                                            }, void 0),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: cn(btn, 'px-2 py-1 text-xs', 'requires-write'),
                                                                onClick: ()=>askDeleteColumn(col.id),
                                                                disabled: readOnly,
                                                                children: "Delete"
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                lineNumber: 814,
                                                                columnNumber: 57
                                                            }, void 0)
                                                        ]
                                                    }, void 0, true),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-xs text-slate-500",
                                                        children: [
                                                            col.issues.length,
                                                            " cards"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                        lineNumber: 823,
                                                        columnNumber: 49
                                                    }, void 0)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                lineNumber: 804,
                                                columnNumber: 45
                                            }, void 0),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3 flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            value: (_newIssueTitleByCol_col_id = newIssueTitleByCol[col.id]) !== null && _newIssueTitleByCol_col_id !== void 0 ? _newIssueTitleByCol_col_id : '',
                                                            onChange: (e)=>setNewIssueTitleByCol((m)=>({
                                                                        ...m,
                                                                        [col.id]: e.target.value
                                                                    })),
                                                            placeholder: "New issue",
                                                            className: cn(input, 'requires-write'),
                                                            disabled: readOnly
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                            lineNumber: 828,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>createIssue(col.id),
                                                            className: cn(btn, 'requires-write'),
                                                            disabled: readOnly || busy === "create-issue:".concat(col.id),
                                                            children: busy === "create-issue:".concat(col.id) ? 'Adding…' : 'Add'
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                            lineNumber: 840,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                    lineNumber: 827,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SortableContext"], {
                                                    items: getIssueIdsByColumn(col.id),
                                                    strategy: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$sortable$40$10$2e$0$2e$0_$40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$sortable$2f$dist$2f$sortable$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["rectSortingStrategy"],
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                        className: "space-y-2",
                                                        children: col.issues.map((iss)=>{
                                                            var _columnsByActive_find;
                                                            var _columnsByActive_find_name;
                                                            const label = (_columnsByActive_find_name = (_columnsByActive_find = columnsByActive.find((c)=>{
                                                                var _iss_columnId;
                                                                return c.id === ((_iss_columnId = iss.columnId) !== null && _iss_columnId !== void 0 ? _iss_columnId : col.id);
                                                            })) === null || _columnsByActive_find === void 0 ? void 0 : _columnsByActive_find.name) !== null && _columnsByActive_find_name !== void 0 ? _columnsByActive_find_name : col.name;
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(SortableIssue, {
                                                                issue: iss,
                                                                draggable: !readOnly,
                                                                children: (editingIssue === null || editingIssue === void 0 ? void 0 : editingIssue.id) === iss.id ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                            value: editingIssue.title,
                                                                            onChange: (e)=>setEditingIssue({
                                                                                    id: iss.id,
                                                                                    title: e.target.value,
                                                                                    colId: col.id
                                                                                }),
                                                                            className: cn(input, 'requires-write'),
                                                                            disabled: readOnly
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                            lineNumber: 858,
                                                                            columnNumber: 69
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            className: cn(btn, 'px-2 py-1 text-xs', 'requires-write'),
                                                                            onClick: ()=>patchIssue(iss.id, editingIssue.title.trim()),
                                                                            disabled: readOnly || busy === "rename-issue:".concat(iss.id),
                                                                            children: busy === "rename-issue:".concat(iss.id) ? 'Saving…' : 'Save'
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                            lineNumber: 866,
                                                                            columnNumber: 69
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                            className: cn(btn, 'px-2 py-1 text-xs', 'requires-write'),
                                                                            onClick: ()=>setEditingIssue(null),
                                                                            disabled: readOnly,
                                                                            children: "Cancel"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                            lineNumber: 873,
                                                                            columnNumber: 69
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                    lineNumber: 857,
                                                                    columnNumber: 65
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex items-center justify-between gap-2",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "min-w-0",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "truncate text-sm font-medium",
                                                                                    children: iss.title
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                                    lineNumber: 884,
                                                                                    columnNumber: 73
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "mb-2 text-xs text-slate-500",
                                                                                    children: label
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                                    lineNumber: 885,
                                                                                    columnNumber: 73
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                            lineNumber: 883,
                                                                            columnNumber: 69
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "shrink-0 flex items-center gap-2",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                    className: cn(btn, 'px-2 py-1 text-xs', 'requires-write'),
                                                                                    onClick: ()=>setEditingIssue({
                                                                                            id: iss.id,
                                                                                            title: iss.title,
                                                                                            colId: col.id
                                                                                        }),
                                                                                    disabled: readOnly,
                                                                                    children: "Rename"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                                    lineNumber: 888,
                                                                                    columnNumber: 73
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                    className: cn(btn, 'px-2 py-1 text-xs', 'requires-write'),
                                                                                    onClick: ()=>askDeleteIssue(iss.id),
                                                                                    disabled: readOnly,
                                                                                    children: "Delete"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                                    lineNumber: 895,
                                                                                    columnNumber: 73
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                            lineNumber: 887,
                                                                            columnNumber: 69
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                    lineNumber: 882,
                                                                    columnNumber: 65
                                                                }, this)
                                                            }, iss.id, false, {
                                                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                                lineNumber: 855,
                                                                columnNumber: 57
                                                            }, this);
                                                        })
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                        lineNumber: 850,
                                                        columnNumber: 45
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                    lineNumber: 849,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, col.id, true, {
                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                            lineNumber: 764,
                                            columnNumber: 37
                                        }, this);
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                    lineNumber: 762,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                lineNumber: 761,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DragOverlay"], {
                                dropAnimation: null,
                                children: overlay
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                lineNumber: 915,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                        lineNumber: 754,
                        columnNumber: 21
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(BoardPicker, {
                        open: pickerOpen,
                        onClose: ()=>setPickerOpen(false),
                        boards: allBoards,
                        selected: selectedBoardIds,
                        onToggle: (id)=>setSelectedBoardIds((prev)=>prev.includes(id) ? prev.filter((x)=>x !== id) : [
                                    ...prev,
                                    id
                                ])
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                        lineNumber: 919,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                lineNumber: 681,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
        lineNumber: 658,
        columnNumber: 9
    }, this);
}
_s2(KanbanPage, "feFoPHhtciYb+OVo2XYZIKkfc4I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$components$2f$Toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"],
        __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$hooks$2f$useRBAC$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRBAC"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensor"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$dnd$2d$kit$2b$core$40$6$2e$3$2e$1_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f40$dnd$2d$kit$2f$core$2f$dist$2f$core$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSensors"]
    ];
});
_c2 = KanbanPage;
function BoardPicker(props) {
    const { open, onClose, boards, selected, onToggle } = props;
    if (!open) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-50",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-black/40",
                onClick: onClose
            }, void 0, false, {
                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                lineNumber: 944,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: cn(card, 'absolute left-1/2 top-1/2 w-[520px] -translate-x-1/2 -translate-y-1/2 p-5'),
                onClick: (e)=>e.stopPropagation(),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3 flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-semibold",
                                children: "Select Boards"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                lineNumber: 950,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: cn(btn, 'px-2 py-1 text-xs'),
                                onClick: onClose,
                                children: "Close"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                lineNumber: 951,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                        lineNumber: 949,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "max-h-[50vh] space-y-2 overflow-auto",
                        children: [
                            boards.map((b)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: cn(card, 'flex items-center justify-between px-3 py-2'),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "min-w-0",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "truncate text-sm font-medium",
                                                    children: b.name
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                    lineNumber: 959,
                                                    columnNumber: 33
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "truncate text-[11px] text-slate-500",
                                                    children: b.id
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                                    lineNumber: 960,
                                                    columnNumber: 33
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                            lineNumber: 958,
                                            columnNumber: 29
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox",
                                            className: "size-4",
                                            checked: selected.includes(b.id),
                                            onChange: ()=>onToggle(b.id)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                            lineNumber: 962,
                                            columnNumber: 29
                                        }, this)
                                    ]
                                }, b.id, true, {
                                    fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                    lineNumber: 957,
                                    columnNumber: 25
                                }, this)),
                            !boards.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$4$2e$7_$40$playwright$2b$test$40$1$2e$56$2e$0_react$2d$dom$40$19$2e$1$2e$0_react$40$19$2e$1$2e$0_$5f$react$40$19$2e$1$2e$0$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-slate-500",
                                children: "No boards"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                                lineNumber: 970,
                                columnNumber: 40
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                        lineNumber: 955,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/src/app/kanban/page.tsx",
                lineNumber: 945,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/src/app/kanban/page.tsx",
        lineNumber: 943,
        columnNumber: 9
    }, this);
}
_c3 = BoardPicker;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "SortableIssue");
__turbopack_context__.k.register(_c1, "SortableColumn");
__turbopack_context__.k.register(_c2, "KanbanPage");
__turbopack_context__.k.register(_c3, "BoardPicker");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=apps_web_src_daa91de1._.js.map