(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_7278af00._.js",
  "static/chunks/7ec5b_next_dist_compiled_react-dom_3a03e05b._.js",
  "static/chunks/7ec5b_next_dist_compiled_next-devtools_index_eec4773d.js",
  "static/chunks/7ec5b_next_dist_compiled_ad663e03._.js",
  "static/chunks/7ec5b_next_dist_client_240805f0._.js",
  "static/chunks/7ec5b_next_dist_6de0b71b._.js",
  "static/chunks/61dca_@swc_helpers_cjs_28edb73c._.js"
],
    source: "entry"
});
